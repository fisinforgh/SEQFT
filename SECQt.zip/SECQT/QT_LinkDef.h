#pragma link C++ class MyMainFrame;
